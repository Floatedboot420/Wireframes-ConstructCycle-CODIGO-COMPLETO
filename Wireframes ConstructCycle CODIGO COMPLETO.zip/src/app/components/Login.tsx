import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "../context/AuthContext";

export function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("Supervisor");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password, role);
    navigate("/dashboard");
  };

  return (
    <div className="size-full flex items-center justify-center bg-white">
      <div className="w-96 border-2 border-black p-8">
        <h1 className="text-2xl mb-8 text-center">ConstructCycle</h1>
        <div className="text-center mb-6 text-sm">Sistema de Gestión de Residuos</div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block mb-2">Correo electrónico</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border-2 border-black p-2"
              placeholder="usuario@constructcycle.com"
              required
            />
          </div>

          <div>
            <label className="block mb-2">Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border-2 border-black p-2"
              placeholder="••••••••"
              required
            />
          </div>

          <div>
            <label className="block mb-2">Rol</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full border-2 border-black p-2"
            >
              <option>Administrador</option>
              <option>Supervisor</option>
              <option>Personal Técnico</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full border-2 border-black p-2 bg-white hover:bg-gray-100"
          >
            Iniciar Sesión
          </button>

          <div className="text-center mt-4">
            <a href="#" className="underline">Registrar nuevo usuario</a>
          </div>
        </form>

        <div className="mt-8 pt-6 border-t-2 border-black text-sm">
          <div className="mb-2">Accesos rápidos:</div>
          <div className="space-y-1">
            <div>• Desktop: Panel completo</div>
            <div>• <a href="/mobile" className="underline">Móvil</a>: Registro desde obra</div>
          </div>
        </div>
      </div>
    </div>
  );
}
