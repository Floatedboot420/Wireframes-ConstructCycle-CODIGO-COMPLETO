import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export function Dashboard() {
  const { user } = useAuth();
  const [hasData, setHasData] = useState(true);

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8 pb-4 border-b-2 border-black">
        <div>
          <h1 className="text-2xl">Dashboard Principal</h1>
          <div className="text-sm mt-1">Bienvenido, {user?.name || "Usuario"}</div>
        </div>
        <div className="border-2 border-black p-3 bg-gray-50">
          <div className="text-xs mb-1">Última actualización:</div>
          <div className="text-sm">2026-05-12 09:30</div>
        </div>
      </div>

      {/* Notificaciones */}
      <div className="mb-8 border-2 border-black p-4 bg-gray-50">
        <div className="flex justify-between items-center">
          <div>
            <div className="mb-1">Notificaciones del Sistema</div>
            <div className="text-sm">2 alertas activas requieren atención</div>
          </div>
          <button className="border-2 border-black px-4 py-2 bg-white hover:bg-gray-100">
            Ver Alertas
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="border-2 border-black p-4">
          <div className="text-sm mb-2">Cantidad de Residuos</div>
          <div className="text-2xl mb-1">1,250 ton</div>
          <div className="text-xs">Total acumulado</div>
        </div>
        <div className="border-2 border-black p-4">
          <div className="text-sm mb-2">Reutilización</div>
          <div className="text-2xl mb-1">35%</div>
          <div className="text-xs">+5% vs mes anterior</div>
        </div>
        <div className="border-2 border-black p-4">
          <div className="text-sm mb-2">Reciclaje</div>
          <div className="text-2xl mb-1">42%</div>
          <div className="text-xs">+3% vs mes anterior</div>
        </div>
        <div className="border-2 border-black p-4">
          <div className="text-sm mb-2">Ahorro Estimado</div>
          <div className="text-2xl mb-1">$15,400</div>
          <div className="text-xs">Último trimestre</div>
        </div>
      </div>

      {/* Métricas Ambientales */}
      <div className="mb-8">
        <h2 className="text-xl mb-4">Métricas Ambientales</h2>
        <div className="grid grid-cols-3 gap-4">
          <div className="border-2 border-black p-4">
            <div className="text-sm mb-2">Reducción de Desperdicios</div>
            <div className="text-2xl mb-1">68%</div>
            <div className="text-xs mb-3">vs promedio industria (45%)</div>
            <div className="border border-black h-3 bg-white">
              <div className="h-full bg-gray-300 border-r border-black" style={{ width: "68%" }}></div>
            </div>
          </div>
          <div className="border-2 border-black p-4">
            <div className="text-sm mb-2">Impacto Ambiental Reducido</div>
            <div className="text-2xl mb-1">-450 ton CO₂</div>
            <div className="text-xs">Equivalente a plantar 1,200 árboles</div>
          </div>
          <div className="border-2 border-black p-4">
            <div className="text-sm mb-2">Eficiencia de Reutilización</div>
            <div className="text-2xl mb-1">77%</div>
            <div className="text-xs mb-3">Material reutilizado in-situ</div>
            <div className="border border-black h-3 bg-white">
              <div className="h-full bg-gray-300 border-r border-black" style={{ width: "77%" }}></div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="border-2 border-black p-4 h-64">
          <div className="mb-4">Distribución por Tipo de Material</div>
          <div className="border border-black h-40 flex items-end justify-around p-2">
            <div className="flex flex-col items-center gap-1">
              <div className="w-12 bg-gray-300 h-32 border border-black"></div>
              <div className="text-xs">Concreto</div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-12 bg-gray-300 h-24 border border-black"></div>
              <div className="text-xs">Acero</div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-12 bg-gray-300 h-28 border border-black"></div>
              <div className="text-xs">Madera</div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-12 bg-gray-300 h-20 border border-black"></div>
              <div className="text-xs">Ladrillo</div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-12 bg-gray-300 h-16 border border-black"></div>
              <div className="text-xs">Tierra</div>
            </div>
          </div>
        </div>

        <div className="border-2 border-black p-4 h-64">
          <div className="mb-4">Estado de Residuos</div>
          <div className="border border-black h-40 flex items-center justify-center relative">
            <div className="w-32 h-32 rounded-full border-8 border-black relative">
              <div className="absolute inset-0 flex items-center justify-center text-xs">
                Gráfico circular
              </div>
            </div>
          </div>
        </div>
      </div>

      {hasData ? (
        <div className="border-2 border-black">
          <div className="p-4 border-b-2 border-black flex justify-between items-center bg-gray-50">
            <div>Residuos Recientes</div>
            <button className="border-2 border-black px-4 py-2 bg-white hover:bg-gray-100">
              Generar Reportes
            </button>
          </div>
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-black">
                <th className="p-4 text-left border-r border-black">Fecha</th>
                <th className="p-4 text-left border-r border-black">Material</th>
                <th className="p-4 text-left border-r border-black">Cantidad</th>
                <th className="p-4 text-left">Estado</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-b border-black">
                  <td className="p-4 border-r border-black">2026-05-{13 - i}</td>
                  <td className="p-4 border-r border-black">Concreto</td>
                  <td className="p-4 border-r border-black">{i * 50} ton</td>
                  <td className="p-4">Almacenado</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="border-2 border-black p-12 text-center">
          <div className="text-xl mb-4">No existen residuos registrados</div>
          <div className="text-sm mb-6">Comience registrando residuos desde la sección correspondiente</div>
          <button className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100">
            Registrar Primer Residuo
          </button>
        </div>
      )}
    </div>
  );
}
