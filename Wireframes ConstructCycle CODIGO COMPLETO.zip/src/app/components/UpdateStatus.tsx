import { useState } from "react";

export function UpdateStatus() {
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [hasData, setHasData] = useState(true);
  const [updated, setUpdated] = useState(false);

  const wasteItems = [
    { id: 1, date: "2026-05-10", material: "Concreto", quantity: "120 ton", status: "Almacenado" },
    { id: 2, date: "2026-05-09", material: "Acero", quantity: "85 ton", status: "Almacenado" },
    { id: 3, date: "2026-05-08", material: "Madera", quantity: "200 ton", status: "Almacenado" },
    { id: 4, date: "2026-05-07", material: "Ladrillo", quantity: "150 ton", status: "Reutilizado" },
    { id: 5, date: "2026-05-06", material: "Tierra", quantity: "300 ton", status: "Reciclado" },
  ];

  const toggleSelection = (id: number) => {
    setSelectedItems(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleUpdate = () => {
    setUpdated(true);
    setSelectedItems([]);
    setTimeout(() => setUpdated(false), 3000);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-8 pb-4 border-b-2 border-black">Actualización de Estado del Residuo</h1>

      {updated && (
        <div className="mb-6 border-2 border-black p-4 bg-gray-50">
          <div className="mb-1">✓ Estados actualizados correctamente</div>
          <div className="text-sm">Los cambios han sido guardados en el sistema</div>
        </div>
      )}

      {hasData ? (
        <>
          <div className="mb-4 p-4 border border-black bg-gray-50">
            <div className="text-sm">Total de residuos: {wasteItems.length} | Seleccionados: {selectedItems.length}</div>
          </div>

          <div className="border-2 border-black mb-8">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-black bg-gray-50">
                  <th className="p-4 text-left border-r border-black">Selección</th>
                  <th className="p-4 text-left border-r border-black">Fecha</th>
                  <th className="p-4 text-left border-r border-black">Material</th>
                  <th className="p-4 text-left border-r border-black">Cantidad</th>
                  <th className="p-4 text-left">Estado Actual</th>
                </tr>
              </thead>
              <tbody>
                {wasteItems.map((item) => (
                  <tr
                    key={item.id}
                    className={`border-b border-black ${selectedItems.includes(item.id) ? "bg-gray-100" : ""}`}
                  >
                    <td className="p-4 border-r border-black">
                      <input
                        type="checkbox"
                        checked={selectedItems.includes(item.id)}
                        onChange={() => toggleSelection(item.id)}
                        className="w-4 h-4"
                      />
                    </td>
                    <td className="p-4 border-r border-black">{item.date}</td>
                    <td className="p-4 border-r border-black">{item.material}</td>
                    <td className="p-4 border-r border-black">{item.quantity}</td>
                    <td className="p-4">{item.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedItems.length > 0 && (
            <div className="max-w-2xl border-2 border-black p-6">
              <h2 className="text-xl mb-6">Actualizar Estado ({selectedItems.length} seleccionado{selectedItems.length > 1 ? 's' : ''})</h2>

              <div className="space-y-4">
                <div>
                  <label className="block mb-2">Nuevo Estado</label>
                  <select className="w-full border-2 border-black p-2">
                    <option value="">Seleccionar estado...</option>
                    <option>Almacenado</option>
                    <option>Reutilizado</option>
                    <option>Reciclado</option>
                    <option>Eliminado</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-2">Comentario (opcional)</label>
                  <textarea
                    className="w-full border-2 border-black p-2"
                    rows={3}
                    placeholder="Observaciones sobre el cambio de estado..."
                  />
                </div>

                <div className="pt-4 border-t border-black flex gap-3">
                  <button
                    onClick={handleUpdate}
                    className="flex-1 border-2 border-black p-3 bg-white hover:bg-gray-100"
                  >
                    Actualizar
                  </button>
                  <button
                    onClick={() => setSelectedItems([])}
                    className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </div>
          )}

          {selectedItems.length === 0 && (
            <div className="max-w-2xl p-4 border border-black bg-gray-50">
              <div>Seleccione uno o más residuos para actualizar su estado</div>
            </div>
          )}
        </>
      ) : (
        <div className="border-2 border-black p-12 text-center">
          <div className="text-xl mb-4">No existen residuos registrados</div>
          <div className="text-sm mb-6">No hay residuos disponibles para actualizar estado</div>
          <button className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100">
            Ir a Registrar Residuos
          </button>
        </div>
      )}
    </div>
  );
}
