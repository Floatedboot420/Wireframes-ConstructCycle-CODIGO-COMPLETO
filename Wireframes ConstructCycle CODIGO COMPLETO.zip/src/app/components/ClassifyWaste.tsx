import { useState } from "react";

export function ClassifyWaste() {
  const [selectedWaste, setSelectedWaste] = useState<number | null>(null);
  const [hasData, setHasData] = useState(true);

  const wasteItems = [
    { id: 1, date: "2026-05-10", material: "Material sin clasificar", quantity: "120 ton", location: "Sector B" },
    { id: 2, date: "2026-05-09", material: "Material sin clasificar", quantity: "85 ton", location: "Sector C" },
    { id: 3, date: "2026-05-08", material: "Material sin clasificar", quantity: "200 ton", location: "Sector A" },
  ];

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-8 pb-4 border-b-2 border-black">Clasificación de Residuos</h1>

      {hasData ? (
        <>
          <div className="mb-4 p-4 border border-black bg-gray-50">
            <div className="text-sm">Residuos pendientes de clasificación: {wasteItems.length}</div>
          </div>

          <div className="border-2 border-black">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-black bg-gray-50">
                  <th className="p-4 text-left border-r border-black">Selección</th>
                  <th className="p-4 text-left border-r border-black">Fecha</th>
                  <th className="p-4 text-left border-r border-black">Material Actual</th>
                  <th className="p-4 text-left border-r border-black">Cantidad</th>
                  <th className="p-4 text-left">Ubicación</th>
                </tr>
              </thead>
              <tbody>
                {wasteItems.map((item) => (
                  <tr
                    key={item.id}
                    className={`border-b border-black ${selectedWaste === item.id ? "bg-gray-100" : ""}`}
                  >
                    <td className="p-4 border-r border-black">
                      <input
                        type="radio"
                        name="waste"
                        checked={selectedWaste === item.id}
                        onChange={() => setSelectedWaste(item.id)}
                        className="w-4 h-4"
                      />
                    </td>
                    <td className="p-4 border-r border-black">{item.date}</td>
                    <td className="p-4 border-r border-black">{item.material}</td>
                    <td className="p-4 border-r border-black">{item.quantity}</td>
                    <td className="p-4">{item.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedWaste && (
            <div className="mt-8 max-w-2xl border-2 border-black p-6">
              <h2 className="text-xl mb-6">Clasificar Residuo Seleccionado</h2>

              <div className="space-y-4">
                <div>
                  <label className="block mb-2">Nueva Categoría</label>
                  <select className="w-full border-2 border-black p-2">
                    <option value="">Seleccionar categoría...</option>
                    <option>Concreto</option>
                    <option>Acero</option>
                    <option>Madera</option>
                    <option>Ladrillo</option>
                    <option>Tierra</option>
                    <option>Plástico</option>
                  </select>
                </div>

                <div className="pt-4 border-t border-black">
                  <button className="w-full border-2 border-black p-3 bg-white hover:bg-gray-100">
                    Confirmar Clasificación
                  </button>
                </div>
              </div>
            </div>
          )}

          {!selectedWaste && (
            <div className="mt-8 p-4 border border-black bg-gray-50 max-w-2xl">
              <div>Seleccione un residuo de la lista para clasificar</div>
            </div>
          )}
        </>
      ) : (
        <div className="border-2 border-black p-12 text-center">
          <div className="text-xl mb-4">No existen residuos pendientes de clasificación</div>
          <div className="text-sm mb-6">Todos los residuos registrados han sido clasificados correctamente</div>
          <div className="border border-black p-4 bg-gray-50 inline-block">
            <div className="text-sm">Estado: 100% clasificado</div>
          </div>
        </div>
      )}
    </div>
  );
}
