import { useState } from "react";

export function RegisterWaste() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-8 pb-4 border-b-2 border-black">Registro de Residuos</h1>

      {submitted && (
        <div className="mb-6 border-2 border-black p-4 bg-gray-50">
          <div className="mb-1">✓ Residuo registrado correctamente</div>
          <div className="text-sm">El registro ha sido guardado en el sistema</div>
        </div>
      )}

      <div className="max-w-2xl">
        <form onSubmit={handleSubmit} className="border-2 border-black p-6 space-y-6">
          <div className="border-b border-black pb-4 mb-4">
            <div className="text-xs">FORMULARIO DE REGISTRO</div>
            <div className="text-sm mt-1">Complete todos los campos obligatorios (*)</div>
          </div>

          <div>
            <label className="block mb-2">
              Tipo de Material <span className="text-red-500">*</span>
            </label>
            <select className="w-full border-2 border-black p-2" required>
              <option value="">Seleccionar...</option>
              <option>Concreto</option>
              <option>Acero</option>
              <option>Madera</option>
              <option>Ladrillo</option>
              <option>Tierra</option>
              <option>Plástico</option>
            </select>
          </div>

          <div>
            <label className="block mb-2">
              Cantidad (toneladas) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              className="w-full border-2 border-black p-2"
              placeholder="0.00"
              step="0.01"
              required
            />
          </div>

          <div>
            <label className="block mb-2">
              Volumen Aproximado (m³) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              className="w-full border-2 border-black p-2"
              placeholder="0.00"
              step="0.01"
              required
            />
          </div>

          <div>
            <label className="block mb-2">
              Ubicación <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className="w-full border-2 border-black p-2"
              placeholder="Ej: Sector A, Piso 3"
              required
            />
          </div>

          <div>
            <label className="block mb-2">Observaciones (opcional)</label>
            <textarea
              className="w-full border-2 border-black p-2"
              rows={3}
              placeholder="Notas adicionales sobre el residuo..."
            />
          </div>

          <div className="pt-4 border-t-2 border-black flex gap-4">
            <button
              type="submit"
              className="flex-1 border-2 border-black p-3 bg-white hover:bg-gray-100"
            >
              Guardar Registro
            </button>
            <button
              type="reset"
              className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100"
            >
              Limpiar
            </button>
          </div>
        </form>

        <div className="mt-4 p-4 border border-black bg-gray-50">
          <div className="text-sm mb-2">* Campos obligatorios</div>
          <div className="text-xs">Tiempo estimado de llenado: 2-3 minutos</div>
        </div>
      </div>
    </div>
  );
}
