import { useState } from "react";
import { Link } from "react-router";
import { useAuth } from "../context/AuthContext";

export function MobileView() {
  const { user } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="size-full bg-white max-w-md mx-auto">
      {/* Header Móvil */}
      <div className="border-b-2 border-black p-4">
        <div className="flex justify-between items-center">
          <div>
            <div className="font-bold">ConstructCycle</div>
            <div className="text-xs">Registro Móvil</div>
          </div>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="border-2 border-black p-2 bg-white"
          >
            {menuOpen ? "×" : "☰"}
          </button>
        </div>

        {user && (
          <div className="mt-3 pt-3 border-t border-black text-sm">
            <div className="text-xs">Usuario: {user.name}</div>
            <div className="text-xs">Rol: {user.role}</div>
          </div>
        )}

        {/* Alertas en Header */}
        <div className="mt-3 border border-black p-2 bg-gray-50 text-sm">
          ⚠ 2 alertas activas
        </div>
      </div>

      {/* Menú desplegable */}
      {menuOpen && (
        <div className="border-b-2 border-black">
          <Link to="/dashboard" className="block p-3 border-b border-black hover:bg-gray-100">
            Dashboard
          </Link>
          <Link to="/register" className="block p-3 border-b border-black hover:bg-gray-100">
            Registrar Residuos
          </Link>
          <Link to="/alerts" className="block p-3 border-b border-black hover:bg-gray-100">
            Ver Alertas
          </Link>
          <Link to="/login" className="block p-3 hover:bg-gray-100">
            Cerrar Sesión
          </Link>
        </div>
      )}

      {/* Contenido Principal */}
      <div className="p-4">
        <h1 className="text-xl mb-1">Registro Rápido desde Obra</h1>
        <div className="text-xs mb-6 text-gray-600">Optimizado para supervisores en campo</div>

        {submitted && (
          <div className="mb-4 border-2 border-black p-3 bg-gray-50">
            <div className="mb-1">✓ Guardado exitosamente</div>
            <div className="text-xs">Sincronizado con el servidor</div>
          </div>
        )}

        {/* Resumen del día */}
        <div className="mb-6 border-2 border-black p-4">
          <div className="text-sm mb-3">Resumen de Hoy</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="border border-black p-2">
              <div className="text-xs">Registros</div>
              <div className="text-xl">8</div>
            </div>
            <div className="border border-black p-2">
              <div className="text-xs">Total (ton)</div>
              <div className="text-xl">125</div>
            </div>
          </div>
        </div>

        {/* Formulario Simplificado */}
        <form onSubmit={handleSubmit} className="border-2 border-black p-4 space-y-4">
          <div className="border-b border-black pb-3">
            <div className="text-sm">Formulario Rápido</div>
          </div>

          <div>
            <label className="block mb-1 text-sm">Material *</label>
            <select className="w-full border-2 border-black p-2" required>
              <option value="">Seleccionar...</option>
              <option>Concreto</option>
              <option>Acero</option>
              <option>Madera</option>
              <option>Ladrillo</option>
              <option>Tierra</option>
              <option>Plástico</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block mb-1 text-sm">Cantidad (ton) *</label>
              <input
                type="number"
                className="w-full border-2 border-black p-2"
                placeholder="0.00"
                step="0.01"
                required
              />
            </div>
            <div>
              <label className="block mb-1 text-sm">Volumen (m³) *</label>
              <input
                type="number"
                className="w-full border-2 border-black p-2"
                placeholder="0.00"
                step="0.01"
                required
              />
            </div>
          </div>

          <div>
            <label className="block mb-1 text-sm">Ubicación *</label>
            <input
              type="text"
              className="w-full border-2 border-black p-2"
              placeholder="Ej: Sector A"
              required
            />
          </div>

          <div>
            <label className="block mb-1 text-sm">Nota rápida</label>
            <textarea
              className="w-full border-2 border-black p-2"
              rows={2}
              placeholder="Observaciones..."
            />
          </div>

          <div className="pt-3 border-t border-black">
            <button
              type="submit"
              className="w-full border-2 border-black p-3 bg-white hover:bg-gray-100"
            >
              Registrar
            </button>
          </div>
        </form>

        {/* Últimos registros */}
        <div className="mt-6 border-2 border-black">
          <div className="p-3 border-b-2 border-black bg-gray-50 text-sm">
            Últimos Registros
          </div>
          <div className="divide-y divide-black">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-3">
                <div className="flex justify-between mb-1">
                  <div className="text-sm">Concreto</div>
                  <div className="text-xs">{i * 20} ton</div>
                </div>
                <div className="text-xs text-gray-600">Sector B - Hace {i}h</div>
              </div>
            ))}
          </div>
        </div>

        {/* Acceso a versión desktop */}
        <div className="mt-6 p-4 border border-black bg-gray-50 text-center">
          <div className="text-xs mb-2">Para más funcionalidades</div>
          <Link to="/dashboard" className="underline text-sm">
            Acceder a versión completa
          </Link>
        </div>
      </div>
    </div>
  );
}
