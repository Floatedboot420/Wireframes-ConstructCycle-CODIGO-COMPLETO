import { Outlet, Link, useLocation } from "react-router";
import { useAuth } from "../context/AuthContext";
import { useState, useEffect } from "react";

export function Layout() {
  const location = useLocation();
  const { user, logout } = useAuth();
  const [alertCount, setAlertCount] = useState(2);

  const navItems = [
    { path: "/dashboard", label: "Dashboard", badge: null },
    { path: "/register", label: "Registrar Residuos", badge: null },
    { path: "/classify", label: "Clasificar Residuos", badge: null },
    { path: "/update", label: "Actualizar Estado", badge: null },
    { path: "/reports", label: "Reportes", badge: null },
    { path: "/alerts", label: "Alertas", badge: alertCount },
    { path: "/help", label: "Ayuda", badge: null },
  ];

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="size-full flex bg-white">
      <nav className="w-64 border-r-2 border-black p-4 flex flex-col">
        <div>
          <h1 className="text-xl mb-2">ConstructCycle</h1>
          <div className="text-xs mb-8 pb-4 border-b-2 border-black">
            Gestión de Residuos
          </div>

          {user && (
            <div className="mb-6 p-3 border-2 border-black bg-gray-50">
              <div className="text-xs mb-1">Usuario:</div>
              <div className="mb-2">{user.name}</div>
              <div className="text-xs mb-1">Rol:</div>
              <div className="text-sm">{user.role}</div>
            </div>
          )}

          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`block p-2 border-2 border-black ${
                    location.pathname === item.path ? "bg-gray-200" : "bg-white"
                  } hover:bg-gray-100 relative`}
                >
                  {item.label}
                  {item.badge !== null && item.badge > 0 && (
                    <span className="absolute right-2 top-2 border border-black px-2 py-1 text-xs bg-white">
                      {item.badge}
                    </span>
                  )}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-auto pt-4 border-t-2 border-black space-y-2">
          <Link to="/mobile" className="block p-2 border-2 border-black bg-white hover:bg-gray-100 text-sm">
            Vista Móvil
          </Link>
          <Link
            to="/login"
            onClick={handleLogout}
            className="block p-2 border-2 border-black bg-white hover:bg-gray-100"
          >
            Cerrar Sesión
          </Link>
        </div>
      </nav>

      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
