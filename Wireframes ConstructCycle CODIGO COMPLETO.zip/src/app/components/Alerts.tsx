import { useState } from "react";

export function Alerts() {
  const [hasActiveAlerts, setHasActiveAlerts] = useState(true);

  const activeAlerts = [
    {
      id: 1,
      date: "2026-05-11 09:15",
      message: "El volumen de residuos en Sector A ha superado el límite establecido (500 m³)",
      location: "Sector A",
      level: "Alta"
    },
    {
      id: 2,
      date: "2026-05-10 14:30",
      message: "El volumen de residuos en Sector C está próximo al límite (85% de capacidad)",
      location: "Sector C",
      level: "Media"
    },
  ];

  const recentAlerts = [
    { id: 3, date: "2026-05-09 11:20", message: "Volumen de residuos normalizado en Sector B", status: "Resuelta" },
    { id: 4, date: "2026-05-08 16:45", message: "Límite superado en Sector D", status: "Resuelta" },
    { id: 5, date: "2026-05-07 10:10", message: "Capacidad al 90% en Sector A", status: "Resuelta" },
  ];

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8 pb-4 border-b-2 border-black">
        <div>
          <h1 className="text-2xl">Alertas del Sistema</h1>
          <div className="text-sm mt-1">Monitoreo y notificaciones en tiempo real</div>
        </div>
        <div className="border-2 border-black px-4 py-2 bg-gray-50">
          <div className="text-xs">Alertas activas:</div>
          <div className="text-2xl">{hasActiveAlerts ? activeAlerts.length : 0}</div>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-xl mb-4">Alertas Activas</h2>

        {hasActiveAlerts && activeAlerts.length > 0 ? (
          <div className="space-y-4">
            {activeAlerts.map((alert) => (
              <div key={alert.id} className="border-2 border-black p-6 bg-gray-50">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="text-sm mb-1">{alert.date}</div>
                    <div className="mb-2">Nivel: {alert.level}</div>
                    <div className="mb-2">Ubicación: {alert.location}</div>
                  </div>
                  <div className="border-2 border-black px-4 py-2 bg-white">
                    ACTIVA
                  </div>
                </div>

                <div className="p-4 border-2 border-black bg-white mb-4">
                  {alert.message}
                </div>

                <div className="flex gap-3">
                  <button className="flex-1 border-2 border-black p-3 bg-white hover:bg-gray-100">
                    Tomar Acción
                  </button>
                  <button className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100">
                    Marcar como Resuelta
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="border-2 border-black p-12 text-center">
            <div className="text-xl mb-4">No hay alertas activas</div>
            <div className="text-sm mb-6">El sistema está funcionando correctamente. Todas las operaciones dentro de los parámetros normales.</div>
            <div className="border border-black p-4 bg-gray-50 inline-block">
              <div className="text-sm">Estado del sistema: NORMAL</div>
            </div>
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl mb-4">Panel de Alertas Recientes</h2>

        <div className="border-2 border-black">
          <div className="p-4 border-b-2 border-black bg-gray-50 flex justify-between items-center">
            <div>Historial de Alertas</div>
            <button className="border-2 border-black px-4 py-2 bg-white hover:bg-gray-100 text-sm">
              Exportar Historial
            </button>
          </div>
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-black">
                <th className="p-4 text-left border-r border-black">Fecha</th>
                <th className="p-4 text-left border-r border-black">Mensaje</th>
                <th className="p-4 text-left">Estado</th>
              </tr>
            </thead>
            <tbody>
              {recentAlerts.map((alert) => (
                <tr key={alert.id} className="border-b border-black">
                  <td className="p-4 border-r border-black">{alert.date}</td>
                  <td className="p-4 border-r border-black">{alert.message}</td>
                  <td className="p-4">{alert.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
