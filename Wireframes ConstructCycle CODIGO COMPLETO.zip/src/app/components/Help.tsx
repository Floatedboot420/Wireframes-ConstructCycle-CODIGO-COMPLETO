export function Help() {
  return (
    <div className="p-8">
      <h1 className="text-2xl mb-8 pb-4 border-b-2 border-black">Centro de Ayuda</h1>

      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="border-2 border-black p-6">
          <h2 className="text-xl mb-4 pb-3 border-b border-black">Primeros Pasos</h2>
          <div className="space-y-3">
            <div className="border border-black p-3">
              <div className="mb-1">1. Registrar Residuos</div>
              <div className="text-sm">Complete el formulario con tipo, cantidad y ubicación</div>
            </div>
            <div className="border border-black p-3">
              <div className="mb-1">2. Clasificar Materiales</div>
              <div className="text-sm">Asigne categorías a los residuos registrados</div>
            </div>
            <div className="border border-black p-3">
              <div className="mb-1">3. Actualizar Estado</div>
              <div className="text-sm">Marque como almacenado, reutilizado o reciclado</div>
            </div>
            <div className="border border-black p-3">
              <div className="mb-1">4. Generar Reportes</div>
              <div className="text-sm">Exporte estadísticas y métricas ambientales</div>
            </div>
          </div>
        </div>

        <div className="border-2 border-black p-6">
          <h2 className="text-xl mb-4 pb-3 border-b border-black">Preguntas Frecuentes</h2>
          <div className="space-y-4">
            <div>
              <div className="mb-1">¿Cómo registro residuos desde obra?</div>
              <div className="text-sm border-l-2 border-black pl-3">
                Use la Vista Móvil optimizada para registro rápido en campo
              </div>
            </div>
            <div>
              <div className="mb-1">¿Qué significan las alertas?</div>
              <div className="text-sm border-l-2 border-black pl-3">
                Indican cuando el volumen de residuos supera límites establecidos
              </div>
            </div>
            <div>
              <div className="mb-1">¿Puedo exportar los reportes?</div>
              <div className="text-sm border-l-2 border-black pl-3">
                Sí, en formato PDF o Excel desde la sección Reportes
              </div>
            </div>
            <div>
              <div className="mb-1">¿Qué son las métricas ambientales?</div>
              <div className="text-sm border-l-2 border-black pl-3">
                Indicadores de sostenibilidad: reducción CO₂, ahorro económico, etc.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="border-2 border-black p-6 mb-6">
        <h2 className="text-xl mb-4 pb-3 border-b border-black">Tipos de Materiales Soportados</h2>
        <div className="grid grid-cols-3 gap-4">
          <div className="border border-black p-3">
            <div className="mb-1">Concreto</div>
            <div className="text-sm">Residuos de hormigón y cemento</div>
          </div>
          <div className="border border-black p-3">
            <div className="mb-1">Acero</div>
            <div className="text-sm">Estructuras metálicas y varillas</div>
          </div>
          <div className="border border-black p-3">
            <div className="mb-1">Madera</div>
            <div className="text-sm">Maderas de construcción y encofrados</div>
          </div>
          <div className="border border-black p-3">
            <div className="mb-1">Ladrillo</div>
            <div className="text-sm">Bloques y ladrillos de construcción</div>
          </div>
          <div className="border border-black p-3">
            <div className="mb-1">Tierra</div>
            <div className="text-sm">Excavación y movimiento de tierras</div>
          </div>
          <div className="border border-black p-3">
            <div className="mb-1">Plástico</div>
            <div className="text-sm">Tuberías, empaques y envases</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="border-2 border-black p-6">
          <h2 className="text-xl mb-4 pb-3 border-b border-black">Soporte Técnico</h2>
          <div className="space-y-3">
            <div className="border border-black p-3 bg-gray-50">
              <div className="text-sm mb-1">Email:</div>
              <div>soporte@constructcycle.com</div>
            </div>
            <div className="border border-black p-3 bg-gray-50">
              <div className="text-sm mb-1">Teléfono:</div>
              <div>+1 (555) 123-4567</div>
            </div>
            <div className="border border-black p-3 bg-gray-50">
              <div className="text-sm mb-1">Horario:</div>
              <div>Lunes a Viernes, 8:00 AM - 6:00 PM</div>
            </div>
          </div>
        </div>

        <div className="border-2 border-black p-6">
          <h2 className="text-xl mb-4 pb-3 border-b border-black">Versión del Sistema</h2>
          <div className="space-y-3">
            <div className="border border-black p-3 bg-gray-50">
              <div className="text-sm mb-1">Versión:</div>
              <div>v1.0.0 - Beta</div>
            </div>
            <div className="border border-black p-3 bg-gray-50">
              <div className="text-sm mb-1">Última actualización:</div>
              <div>12 de Mayo, 2026</div>
            </div>
            <div className="border border-black p-3 bg-gray-50">
              <div className="text-sm mb-1">Compatibilidad:</div>
              <div>Desktop, Tablet, Móvil</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
