import { useState } from "react";

export function Reports() {
  const [hasData, setHasData] = useState(true);
  const [exported, setExported] = useState(false);

  const reportData = [
    {
      material: "Concreto",
      total: "450 ton",
      reutilizado: "180 ton (40%)",
      reciclado: "200 ton (44%)",
      eliminado: "70 ton (16%)"
    },
    {
      material: "Acero",
      total: "250 ton",
      reutilizado: "100 ton (40%)",
      reciclado: "140 ton (56%)",
      eliminado: "10 ton (4%)"
    },
    {
      material: "Madera",
      total: "180 ton",
      reutilizado: "80 ton (44%)",
      reciclado: "60 ton (33%)",
      eliminado: "40 ton (22%)"
    },
    {
      material: "Ladrillo",
      total: "320 ton",
      reutilizado: "150 ton (47%)",
      reciclado: "120 ton (38%)",
      eliminado: "50 ton (16%)"
    },
    {
      material: "Tierra",
      total: "600 ton",
      reutilizado: "250 ton (42%)",
      reciclado: "300 ton (50%)",
      eliminado: "50 ton (8%)"
    },
  ];

  const handleExport = (format: string) => {
    setExported(true);
    setTimeout(() => setExported(false), 3000);
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8 pb-4 border-b-2 border-black">
        <div>
          <h1 className="text-2xl">Reportes y Estadísticas</h1>
          <div className="text-sm mt-1">Análisis detallado de gestión de residuos</div>
        </div>
        <div className="border-2 border-black px-4 py-2 bg-gray-50">
          <div className="text-xs">Período:</div>
          <div className="text-sm">Último trimestre</div>
        </div>
      </div>

      {exported && (
        <div className="mb-6 border-2 border-black p-4 bg-gray-50">
          <div className="mb-1">✓ Reporte exportado correctamente</div>
          <div className="text-sm">El archivo se ha descargado</div>
        </div>
      )}

      {hasData ? (
        <>
          <div className="mb-6 grid grid-cols-4 gap-4">
            <div className="border-2 border-black p-4">
              <div className="text-sm mb-2">Total Residuos</div>
              <div className="text-2xl mb-1">1,800 ton</div>
              <div className="text-xs">100% procesado</div>
            </div>
            <div className="border-2 border-black p-4">
              <div className="text-sm mb-2">Total Reutilizado</div>
              <div className="text-2xl mb-1">760 ton</div>
              <div className="text-xs">42% del total</div>
            </div>
            <div className="border-2 border-black p-4">
              <div className="text-sm mb-2">Total Reciclado</div>
              <div className="text-2xl mb-1">820 ton</div>
              <div className="text-xs">46% del total</div>
            </div>
            <div className="border-2 border-black p-4">
              <div className="text-sm mb-2">Total Eliminado</div>
              <div className="text-2xl mb-1">220 ton</div>
              <div className="text-xs">12% del total</div>
            </div>
          </div>

          {/* Impacto Ambiental */}
          <div className="mb-6 border-2 border-black p-6">
            <h2 className="text-xl mb-4 pb-3 border-b border-black">Impacto Ambiental y Sostenibilidad</h2>
            <div className="grid grid-cols-3 gap-4">
              <div className="border border-black p-4">
                <div className="text-sm mb-2">Reducción de Desperdicios</div>
                <div className="text-xl mb-1">88%</div>
                <div className="text-xs">1,580 ton aprovechadas</div>
              </div>
              <div className="border border-black p-4">
                <div className="text-sm mb-2">Ahorro Económico Total</div>
                <div className="text-xl mb-1">$45,200</div>
                <div className="text-xs">vs disposición tradicional</div>
              </div>
              <div className="border border-black p-4">
                <div className="text-sm mb-2">Reducción CO₂</div>
                <div className="text-xl mb-1">-1,240 ton</div>
                <div className="text-xs">Emisiones evitadas</div>
              </div>
            </div>
          </div>

          <div className="border-2 border-black mb-6">
            <div className="p-4 border-b-2 border-black bg-gray-50">
              <h2 className="text-xl">Agrupación por Tipo de Material</h2>
            </div>
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-black">
                  <th className="p-4 text-left border-r border-black">Material</th>
                  <th className="p-4 text-left border-r border-black">Total</th>
                  <th className="p-4 text-left border-r border-black">Reutilizado</th>
                  <th className="p-4 text-left border-r border-black">Reciclado</th>
                  <th className="p-4 text-left">Eliminado</th>
                </tr>
              </thead>
              <tbody>
                {reportData.map((row, index) => (
                  <tr key={index} className="border-b border-black">
                    <td className="p-4 border-r border-black">{row.material}</td>
                    <td className="p-4 border-r border-black">{row.total}</td>
                    <td className="p-4 border-r border-black">{row.reutilizado}</td>
                    <td className="p-4 border-r border-black">{row.reciclado}</td>
                    <td className="p-4">{row.eliminado}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => handleExport('pdf')}
              className="flex-1 border-2 border-black p-3 bg-white hover:bg-gray-100"
            >
              Exportar Reporte (PDF)
            </button>
            <button
              onClick={() => handleExport('excel')}
              className="flex-1 border-2 border-black p-3 bg-white hover:bg-gray-100"
            >
              Exportar Reporte (Excel)
            </button>
            <button className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100">
              Imprimir
            </button>
          </div>
        </>
      ) : (
        <div className="border-2 border-black p-12 text-center">
          <div className="text-xl mb-4">No hay datos suficientes para generar reportes</div>
          <div className="text-sm mb-6">Registre residuos para comenzar a generar estadísticas y reportes</div>
          <button className="border-2 border-black px-6 py-3 bg-white hover:bg-gray-100">
            Ir a Registrar Residuos
          </button>
        </div>
      )}
    </div>
  );
}
