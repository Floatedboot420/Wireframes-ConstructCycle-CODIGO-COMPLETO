import { BrowserRouter, Routes, Route, Navigate } from "react-router";
import { AuthProvider } from "./context/AuthContext";
import { Login } from "./components/Login";
import { Dashboard } from "./components/Dashboard";
import { RegisterWaste } from "./components/RegisterWaste";
import { ClassifyWaste } from "./components/ClassifyWaste";
import { UpdateStatus } from "./components/UpdateStatus";
import { Reports } from "./components/Reports";
import { Alerts } from "./components/Alerts";
import { Help } from "./components/Help";
import { Layout } from "./components/Layout";
import { MobileView } from "./components/MobileView";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/mobile" element={<MobileView />} />
          <Route path="/" element={<Layout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="register" element={<RegisterWaste />} />
            <Route path="classify" element={<ClassifyWaste />} />
            <Route path="update" element={<UpdateStatus />} />
            <Route path="reports" element={<Reports />} />
            <Route path="alerts" element={<Alerts />} />
            <Route path="help" element={<Help />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}