# ConstructCycle - Guía de Wireframes de Baja Fidelidad

## Sistema de Gestión de Residuos de Construcción en Tiempo Real

---

## Descripción General

ConstructCycle es una aplicación web empresarial para la gestión integral de residuos de construcción. Los wireframes están diseñados en baja fidelidad, priorizando estructura, usabilidad y funcionalidad sobre diseño visual.

---

## Características Implementadas

### ✓ 1. Sistema de Autenticación
- **Pantalla de Login** con roles de usuario
- **Roles disponibles:**
  - Administrador
  - Supervisor
  - Personal Técnico
- **Usuario autenticado** visible en sidebar
- **Persistencia de sesión** mediante Context API

### ✓ 2. Dashboard Principal
- **Métricas clave:**
  - Cantidad total de residuos
  - Porcentaje de reutilización
  - Porcentaje de reciclaje
  - Ahorro económico estimado
- **Métricas ambientales:**
  - Reducción de desperdicios (%)
  - Impacto ambiental reducido (ton CO₂)
  - Eficiencia de reutilización
- **Gráficos simples:**
  - Distribución por tipo de material (barras)
  - Estado de residuos (circular)
- **Tabla de residuos recientes**
- **Notificaciones del sistema**

### ✓ 3. Registro de Residuos
- **Formulario completo** con validación
- **Campos obligatorios:**
  - Tipo de material
  - Cantidad (toneladas)
  - Volumen aproximado (m³)
  - Ubicación
- **Campo opcional:** Observaciones
- **Feedback visual** al guardar
- **Botones:** Guardar y Limpiar

### ✓ 4. Clasificación de Residuos
- **Lista de residuos** sin clasificar
- **Selección por radio button**
- **Categorías disponibles:**
  - Concreto
  - Acero
  - Madera
  - Ladrillo
  - Tierra
  - Plástico
- **Estado vacío** cuando no hay residuos pendientes

### ✓ 5. Actualización de Estado
- **Lista de residuos** con checkbox múltiple
- **Estados posibles:**
  - Almacenado
  - Reutilizado
  - Reciclado
  - Eliminado
- **Contador de seleccionados**
- **Campo de comentarios** opcional
- **Feedback visual** al actualizar

### ✓ 6. Reportes y Estadísticas
- **Resumen general** con totales
- **Métricas de impacto ambiental:**
  - Reducción de desperdicios
  - Ahorro económico total
  - Reducción de CO₂
- **Tabla agrupada** por tipo de material
- **Indicadores de:**
  - Total reutilizado
  - Total reciclado
  - Total eliminado
- **Opciones de exportación:**
  - PDF
  - Excel
  - Imprimir

### ✓ 7. Alertas del Sistema
- **Alertas activas** destacadas
- **Información por alerta:**
  - Fecha y hora
  - Nivel de alerta (Alta/Media)
  - Ubicación
  - Mensaje descriptivo
- **Acciones disponibles:**
  - Tomar acción
  - Marcar como resuelta
- **Panel de alertas recientes** (historial)
- **Estado vacío** cuando no hay alertas

### ✓ 8. Diseño Responsive
- **Vista Desktop:** Panel completo con sidebar
- **Vista Móvil/Tablet:**
  - Menú hamburguesa
  - Formulario optimizado
  - Resumen del día
  - Últimos registros
  - Registro rápido desde obra

### ✓ 9. Notificaciones Visuales
- **Badge de alertas** en navegación
- **Notificaciones del sistema** en dashboard
- **Contador de alertas activas**
- **Feedback visual** en formularios

### ✓ 10. Estados Vacíos
- **Dashboard:** "No existen residuos registrados"
- **Clasificación:** "No existen residuos pendientes de clasificación"
- **Actualización:** "No existen residuos registrados"
- **Alertas:** "No hay alertas activas"
- **Reportes:** "No hay datos suficientes para generar reportes"

---

## Flujo de Navegación

```
Login
  ↓
Dashboard Principal
  ↓
  ├─→ Registrar Residuos
  │     ↓
  │   Clasificar Residuos
  │     ↓
  │   Actualizar Estado
  │     ↓
  │   Reportes
  │
  ├─→ Alertas
  │
  └─→ Vista Móvil (para supervisores en campo)
```

---

## Roles y Permisos

### Administrador
- Acceso completo a todas las pantallas
- Generación de reportes
- Gestión de alertas
- Exportación de datos

### Supervisor
- Registro de residuos
- Clasificación de residuos
- Actualización de estado
- Vista de alertas
- **Vista móvil optimizada** para registro desde obra

### Personal Técnico
- Registro de residuos
- Vista de dashboard
- Consulta de reportes

---

## Características de Diseño

### Estilo Visual
- **Wireframes de baja fidelidad**
- **Sin colores** (solo blanco, negro y grises)
- **Sin íconos complejos**
- **Bordes negros** de 2px para elementos principales
- **Tipografía simple** sin estilos elaborados

### Usabilidad
- **Navegación clara** mediante sidebar
- **Formularios simples** y directos
- **Tablas organizadas** con bordes y separadores
- **Botones grandes** y fáciles de clickear
- **Feedback visual** en todas las acciones
- **Estados vacíos** informativos

### Responsive
- **Desktop:** Layout de 2 columnas (sidebar + contenido)
- **Móvil:** Layout de 1 columna con menú hamburguesa
- **Formularios adaptados** a pantalla pequeña
- **Tablas scrolleables** en móvil

---

## Métricas Ambientales y Sostenibilidad

El sistema hace énfasis en:
- **Reducción de desperdicios**
- **Porcentaje reutilizado**
- **Impacto ambiental reducido** (ton CO₂)
- **Ahorro económico estimado**
- **Eficiencia de reutilización**

---

## Compatibilidad

- ✓ Desktop (1920x1080 y superiores)
- ✓ Laptop (1366x768)
- ✓ Tablet (768x1024)
- ✓ Móvil (375x667 y superiores)

---

## Tecnologías Utilizadas

- **React 18.3.1** con TypeScript
- **React Router 7.13.0** para navegación
- **Tailwind CSS 4.1** para estilos
- **Context API** para autenticación
- **Componentes funcionales** con Hooks

---

## Próximos Pasos Sugeridos

1. Añadir validaciones avanzadas en formularios
2. Implementar backend con API REST
3. Añadir gráficos interactivos
4. Sistema de permisos por rol
5. Notificaciones push en tiempo real
6. Geolocalización para registro de ubicación
7. Carga de fotos de residuos
8. Dashboard con filtros por fecha
9. Exportación automática de reportes
10. Integración con sensores IoT

---

## Notas de Implementación

- Los wireframes priorizan **usabilidad** sobre diseño visual
- El sistema está pensado para **uso en obra** (mobile-first para supervisores)
- Las **métricas ambientales** son parte central del dashboard
- Los **estados vacíos** guían al usuario cuando no hay datos
- El **feedback visual** confirma cada acción del usuario

---

**Diseñado para:** Gestión profesional de residuos de construcción  
**Usuario objetivo:** Supervisores de obra, administradores, personal técnico  
**Enfoque:** Wireframes funcionales tipo sistema empresarial universitario
