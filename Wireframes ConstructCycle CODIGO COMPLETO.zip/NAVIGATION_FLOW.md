# ConstructCycle - Flujo de Navegación Detallado

## Diagrama de Flujo del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                          INICIO                                  │
│                      (Usuario no autenticado)                   │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PANTALLA DE LOGIN                             │
│  • Correo electrónico                                           │
│  • Contraseña                                                   │
│  • Selección de rol (Admin/Supervisor/Personal Técnico)        │
│  • Botón: Iniciar Sesión                                        │
│  • Link: Registrar nuevo usuario                                │
│  • Link: Vista Móvil (acceso directo)                          │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼ [Usuario se autentica]
                         │
┌─────────────────────────────────────────────────────────────────┐
│                    LAYOUT PRINCIPAL                              │
│                                                                  │
│  ┌──────────────┐  ┌──────────────────────────────────────┐   │
│  │   SIDEBAR    │  │      CONTENIDO PRINCIPAL              │   │
│  │              │  │                                        │   │
│  │ • Logo       │  │  [Pantalla seleccionada se            │   │
│  │ • Info User  │  │   muestra aquí]                       │   │
│  │ • Dashboard  │  │                                        │   │
│  │ • Registrar  │  │                                        │   │
│  │ • Clasificar │  │                                        │   │
│  │ • Actualizar │  │                                        │   │
│  │ • Reportes   │  │                                        │   │
│  │ • Alertas ②  │  │                                        │   │
│  │ • Vista Móvil│  │                                        │   │
│  │ • Cerrar Ses │  │                                        │   │
│  └──────────────┘  └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼ [Por defecto redirige a]
                         │
┌─────────────────────────────────────────────────────────────────┐
│                   DASHBOARD PRINCIPAL                            │
│                                                                  │
│  • Header: Bienvenida + Usuario + Última actualización         │
│  • Notificaciones del sistema (2 alertas activas)              │
│  • 4 Métricas clave:                                            │
│    - Cantidad de Residuos                                       │
│    - Reutilización (%)                                          │
│    - Reciclaje (%)                                              │
│    - Ahorro Estimado ($)                                        │
│  • Métricas Ambientales:                                        │
│    - Reducción de desperdicios                                  │
│    - Impacto ambiental reducido (CO₂)                          │
│    - Eficiencia de reutilización                               │
│  • Gráficos:                                                    │
│    - Distribución por material (barras)                         │
│    - Estado de residuos (circular)                              │
│  • Tabla: Residuos recientes                                   │
│  • Botón: Generar Reportes                                     │
│                                                                  │
│  └─ Estado vacío: "No existen residuos registrados"            │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼ [Usuario navega a]
                         │
         ┌───────────────┼───────────────┬──────────────┬────────┐
         │               │               │              │        │
         ▼               ▼               ▼              ▼        ▼
    [REGISTRAR]   [CLASIFICAR]   [ACTUALIZAR]   [REPORTES] [ALERTAS]


┌─────────────────────────────────────────────────────────────────┐
│              PANTALLA: REGISTRAR RESIDUOS                        │
│                                                                  │
│  • Formulario:                                                  │
│    - Tipo de Material * (select)                                │
│    - Cantidad (ton) * (number)                                  │
│    - Volumen (m³) * (number)                                    │
│    - Ubicación * (text)                                         │
│    - Observaciones (textarea, opcional)                         │
│  • Botones:                                                     │
│    - Guardar Registro                                           │
│    - Limpiar                                                    │
│  • Feedback: "✓ Residuo registrado correctamente"              │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼ [Después de registrar]
                         │
┌─────────────────────────────────────────────────────────────────┐
│            PANTALLA: CLASIFICAR RESIDUOS                         │
│                                                                  │
│  • Contador: "Residuos pendientes de clasificación: 3"         │
│  • Tabla de residuos sin clasificar:                           │
│    - Radio button para selección                                │
│    - Fecha, Material actual, Cantidad, Ubicación               │
│  • Formulario de clasificación:                                 │
│    - Nueva Categoría (select)                                   │
│    - Botón: Confirmar Clasificación                            │
│  • Mensaje: "Seleccione un residuo de la lista"               │
│                                                                  │
│  └─ Estado vacío: "No existen residuos pendientes"            │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼ [Después de clasificar]
                         │
┌─────────────────────────────────────────────────────────────────┐
│          PANTALLA: ACTUALIZAR ESTADO                             │
│                                                                  │
│  • Contador: "Total: 5 | Seleccionados: 2"                     │
│  • Tabla con checkbox múltiple:                                 │
│    - Fecha, Material, Cantidad, Estado Actual                   │
│  • Formulario de actualización:                                 │
│    - Nuevo Estado (select)                                      │
│    - Comentario (opcional)                                      │
│    - Botones: Actualizar / Cancelar                            │
│  • Feedback: "✓ Estados actualizados correctamente"           │
│                                                                  │
│  └─ Estado vacío: "No existen residuos registrados"           │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼ [Consultar resultados]
                         │
┌─────────────────────────────────────────────────────────────────┐
│               PANTALLA: REPORTES                                 │
│                                                                  │
│  • Header: Período (Último trimestre)                           │
│  • 4 Métricas de resumen:                                       │
│    - Total Residuos, Reutilizado, Reciclado, Eliminado        │
│  • Sección: Impacto Ambiental y Sostenibilidad                 │
│    - Reducción de desperdicios (%)                              │
│    - Ahorro económico total ($)                                │
│    - Reducción CO₂ (ton)                                        │
│  • Tabla: Agrupación por tipo de material                      │
│  • Botones de exportación:                                      │
│    - Exportar PDF                                               │
│    - Exportar Excel                                             │
│    - Imprimir                                                   │
│  • Feedback: "✓ Reporte exportado correctamente"              │
│                                                                  │
│  └─ Estado vacío: "No hay datos suficientes"                  │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼ [Revisar alertas]
                         │
┌─────────────────────────────────────────────────────────────────┐
│                PANTALLA: ALERTAS                                 │
│                                                                  │
│  • Header: Contador de alertas activas (2)                     │
│  • Sección: Alertas Activas                                     │
│    - Fecha, Nivel (Alta/Media), Ubicación                       │
│    - Mensaje descriptivo                                        │
│    - Botones: Tomar Acción / Marcar Resuelta                   │
│  • Sección: Panel de Alertas Recientes                         │
│    - Tabla con historial                                        │
│    - Botón: Exportar Historial                                  │
│                                                                  │
│  └─ Estado vacío: "No hay alertas activas"                    │
└─────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────┐
│                    VISTA MÓVIL                                   │
│               (Optimizada para supervisores)                     │
│                                                                  │
│  • Header Móvil:                                                │
│    - Logo + Menú hamburguesa                                    │
│    - Info usuario (nombre + rol)                                │
│    - Badge de alertas: "⚠ 2 alertas activas"                  │
│  • Menú desplegable:                                            │
│    - Dashboard                                                  │
│    - Registrar Residuos                                         │
│    - Ver Alertas                                                │
│    - Cerrar Sesión                                              │
│  • Resumen del día:                                             │
│    - Registros hoy: 8                                           │
│    - Total (ton): 125                                           │
│  • Formulario rápido simplificado:                              │
│    - Material, Cantidad, Volumen, Ubicación, Nota              │
│    - Botón: Registrar                                           │
│  • Últimos registros (lista compacta)                           │
│  • Link: "Acceder a versión completa"                          │
└─────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────┐
│                   FLUJO DE USUARIO TÍPICO                        │
└─────────────────────────────────────────────────────────────────┘

SUPERVISOR EN OBRA (MÓVIL):
1. Login → Vista Móvil
2. Ver resumen del día
3. Registrar residuo rápido
4. Confirmar registro
5. Ver últimos registros
6. (Opcional) Cambiar a vista completa

ADMINISTRADOR (DESKTOP):
1. Login → Dashboard
2. Revisar métricas y notificaciones
3. Navegar a Clasificar Residuos
4. Clasificar residuos pendientes
5. Actualizar estados
6. Generar reportes
7. Exportar reporte (PDF/Excel)
8. Revisar alertas activas
9. Tomar acción sobre alertas

PERSONAL TÉCNICO (DESKTOP):
1. Login → Dashboard
2. Navegar a Registrar Residuos
3. Completar formulario detallado
4. Guardar registro
5. Consultar reportes
6. Cerrar sesión


┌─────────────────────────────────────────────────────────────────┐
│                INTERACCIONES CLAVE                               │
└─────────────────────────────────────────────────────────────────┘

• Cada acción muestra FEEDBACK VISUAL inmediato
• Estados vacíos guían al usuario con mensajes claros
• Navegación consistente mediante sidebar siempre visible
• Badge de alertas actualizado en tiempo real
• Información del usuario visible en todo momento
• Botones con hover states para mejor UX
• Formularios con validación de campos obligatorios
• Exportación con confirmación visual


┌─────────────────────────────────────────────────────────────────┐
│                    RESPONSIVE BREAKPOINTS                        │
└─────────────────────────────────────────────────────────────────┘

Desktop (1920px+):    Sidebar fijo + contenido amplio
Laptop (1366px):      Sidebar fijo + contenido adaptado
Tablet (768px):       Sidebar colapsable + contenido optimizado
Móvil (375px+):       Vista móvil dedicada + menú hamburguesa
```

---

## Accesos Directos

- **Login → Dashboard** (automático después de autenticarse)
- **Dashboard → Generar Reportes** (botón directo)
- **Sidebar → Cualquier pantalla** (navegación rápida)
- **Vista Móvil → Vista Desktop** (link directo)
- **Alertas en Sidebar** (badge con contador)

---

## Permisos por Rol

| Pantalla              | Admin | Supervisor | Personal Técnico |
|-----------------------|-------|------------|------------------|
| Dashboard             | ✓     | ✓          | ✓                |
| Registrar Residuos    | ✓     | ✓          | ✓                |
| Clasificar Residuos   | ✓     | ✓          | ✗                |
| Actualizar Estado     | ✓     | ✓          | ✗                |
| Reportes              | ✓     | ✓          | ✓ (solo lectura) |
| Alertas               | ✓     | ✓          | ✓ (solo lectura) |
| Vista Móvil           | ✓     | ✓          | ✓                |
| Exportar              | ✓     | ✗          | ✗                |

---

## Estados del Sistema

1. **Sin datos** → Mostrar estados vacíos con call-to-action
2. **Con datos** → Mostrar tablas, gráficos y métricas
3. **Alertas activas** → Badge en sidebar + notificación en dashboard
4. **Sin alertas** → Mensaje "Estado del sistema: NORMAL"
5. **Formulario enviado** → Feedback visual de confirmación
6. **Error** → Mensaje de error con sugerencia de acción

---

**Diseño pensado para flujo de trabajo real en obras de construcción**
