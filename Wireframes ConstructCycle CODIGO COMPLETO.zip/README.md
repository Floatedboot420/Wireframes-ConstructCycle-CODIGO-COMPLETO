
  # Wireframes para ConstructCycle

  This is a code bundle for Wireframes para ConstructCycle. The original project is available at https://www.figma.com/design/bO2mAnTCnWy40LFlXWkv6G/Wireframes-para-ConstructCycle.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  